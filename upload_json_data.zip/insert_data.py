from utils import insert_tweets


insert_tweets("amlo_tweets_01.json", "x_app", "tweetsLatest_AMLO", "juan", "lokura22")