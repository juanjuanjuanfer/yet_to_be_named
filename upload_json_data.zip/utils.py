import json
from connection_mongo import connect_to_mongo


def insert_tweets(path:str, database:str, collection:str, username:str, password:str) -> None:

    client = connect_to_mongo(username, password)

    db = client[database]

    collection = db[collection]


    with open(path, "r", encoding = "utf-8") as file:

        for line in file:

            if collection.find_one({"tweetId": json.loads(line)["tweetId"]}):

                print(f"Tweet {json.loads(line)['tweetId']} already in the collection")


            else:

                collection.insert_one(json.loads(line))

                print(f"Tweet {json.loads(line)['tweetId']} inserted")